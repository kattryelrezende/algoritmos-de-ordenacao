#ifndef VETORES_H
    #define VETORES_H

    extern int vetor_100_ordenado[100];
    extern int vetor_100_inverso[100];
    extern int* vetor_100_aleatorio[5];

    extern int vetor_1000_ordenado[1000];
    extern int vetor_1000_inverso[1000];
    extern int* vetor_1000_aleatorio[5];

    extern int vetor_10000_ordenado[10000];
    extern int vetor_10000_inverso[10000];
    extern int* vetor_10000_aleatorio[5];

    extern int vetor_100000_ordenado[100000];
    extern int vetor_100000_inverso[100000];
    extern int* vetor_100000_aleatorio[5];

#endif 
